//
//  FileTableViewCell.h
//  Simple Download Manager
//
//  Created by Tom Metzger on 12/28/16.
//  Copyright © 2016 Tom Metzger. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface FileTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UILabel *fileNameLabel;

@end
