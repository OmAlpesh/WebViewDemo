//
//  FileBrowserTableViewController.h
//  Simple Download Manager
//
//  Created by Tom Metzger on 12/27/16.
//  Copyright © 2016 Tom Metzger. All rights reserved.
//

#import <UIKit/UIKit.h>



@interface FileBrowserTableViewController : UITableViewController

@property (strong, nonatomic) NSMutableArray *documentsDirectoryFiles;

@end
