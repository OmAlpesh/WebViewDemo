//
//  AppDelegate.h
//  WebViewDemo
//
//  Created by alpesh on 23/06/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

