//
//  ViewController.m
//  WebViewDemo
//
//  Created by alpesh on 23/06/18.
//  Copyright © 2018 alpesh. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){
    
    __weak IBOutlet UIWebView *webViewObj;
    NSString *kTouchJavaScriptString;
    int gesState;
    NSString *imgURL;
    NSTimer *timer;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    // MARK: - Vars & Lets
    kTouchJavaScriptString = @"document.ontouchstart=function(event){x=event.targetTouches[0].clientX;y=event.targetTouches[0].clientY;document.location=\"myweb:touch:start:\"+x+\":\"+y;};document.ontouchmove=function(event){x=event.targetTouches[0].clientX;y=event.targetTouches[0].clientY;document.location=\"myweb:touch:move:\"+x+\":\"+y;};document.ontouchcancel=function(event){document.location=\"myweb:touch:cancel\";};document.ontouchend=function(event){document.location=\"myweb:touch:end\";};";
    
    gesState = 0;
    imgURL = @"";
  
    NSURL *targetURL = [NSURL URLWithString:@"https://education.github.com/"];
    NSURLRequest *request = [NSURLRequest requestWithURL:targetURL];
    [webViewObj loadRequest:request];
}


- (void)loadRequest:(NSURLRequest *)request{
    
}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType{
    
    if ([request.URL.absoluteString  isEqual: @"about:blank"]) {
        return false;
    }
    
    NSString *requestString = request.URL.absoluteString;
    NSArray *components = [requestString componentsSeparatedByString:@":"];
    if (components.count >1 && [components[0]  isEqual: @"myweb"]) {
        if ([components[1] isEqual:@"touch"]) {
            if ([components[2] isEqual:@"start"]) {
                id ptX = components[3];
                id ptY = components[4];
                NSString *js = [NSString stringWithFormat:@"document.elementFromPoint(%@,%@).tagName",ptX,ptY];
                NSLog(@"js--->%@",js);
                //document.elementFromPoint(198.0, 663.0).tagName
                NSString *tagName = [webViewObj stringByEvaluatingJavaScriptFromString:js];
                 NSLog(@"tagName--->%@",tagName);
                imgURL = @"";
                
                if ([tagName isEqualToString:@"IMG"]) {
                    imgURL = [webViewObj stringByEvaluatingJavaScriptFromString:[NSString stringWithFormat:@"document.elementFromPoint(%@, %@).src",ptX,ptY]];
                  
                    NSURL *urlImage = [[NSURL alloc] initWithString:imgURL];
                    
                        NSData *data = [NSData dataWithContentsOfURL:urlImage];
                    
                        UIImage *getImage = [UIImage imageWithData:data];
                        
                        NSData *newImagePNG = UIImagePNGRepresentation(getImage);
                        
                        UIImage *saveableImage = [UIImage imageWithData:newImagePNG];
                     NSLog(@"saveableImage--->%@",saveableImage);
                        //UIImageWriteToSavedPhotosAlbum(saveableImage,self,@selector(image:didFinishSavingWithError:),nil);
                
                }
        }
        else {
            if ([components[2] isEqual:@"move"]) {
                gesState = 2;
            } else {
                if ([components[2] isEqual:@"end"]) {
                    gesState = 4;
                }
            }
        }
    }
    return false;
    }
    return true;
}
- (void)webViewDidStartLoad:(UIWebView *)webView{
    
}
- (void)webViewDidFinishLoad:(UIWebView *)webView{
    [webViewObj stringByEvaluatingJavaScriptFromString:kTouchJavaScriptString];
}
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error{
    
}

-(BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch {
    NSLog(@"TAPPED");
    //Touch gestures below top bar should not make the page turn.
    //EDITED Check for only Tap here instead.
    if ([gestureRecognizer isKindOfClass:[UITapGestureRecognizer class]]) {
        CGPoint touchPoint = [touch locationInView:self.view];
        
        NSUserDefaults * userDefaults = [NSUserDefaults standardUserDefaults];
        bool pageFlag = [userDefaults boolForKey:@"pageDirectionRTLFlag"];
        NSLog(@"pageFlag tapbtnRight %d", pageFlag);
        
        if(self.interfaceOrientation==UIInterfaceOrientationPortrait||self.interfaceOrientation==UIInterfaceOrientationPortraitUpsideDown) {
            NSString *imgURL = [NSString stringWithFormat:@"document.elementFromPoint(%f, %f).src", touchPoint.x, touchPoint.y];
            NSString *urlToSave = [webViewObj stringByEvaluatingJavaScriptFromString:imgURL];
            NSLog(@"urlToSave :%@",urlToSave);
            NSURL * imageURL = [NSURL URLWithString:urlToSave];
            NSData * imageData = [NSData dataWithContentsOfURL:imageURL];
            UIImage * image = [UIImage imageWithData:imageData];
            NSLog(@"image -- %@", image);
        }
    }
    return YES;
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

//-(void)userDefineSaveImageMethod {
//    dispatch_async(dispatch_get_global_queue( DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
//
//
//        NSData *data = [NSData dataWithContentsOfURL:self->imgURL];
//       UIImage *getImage = [UIImage imageWithData:data];
//
//      NSData *newImagePNG = UIImagePNGRepresentation(getImage);
//
//        UIImage *saveableImage = [UIImage imageWithData:newImagePNG];
//        UIImageWriteToSavedPhotosAlbum(saveableImage,self,@selector(image:didFinishSavingWithError:),nil);
//    });
//}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error{
    if ([error isEqual:nil]) {
        NSLog(@"Fail");
    }else {
        NSLog(@"success");
    }
}

@end
