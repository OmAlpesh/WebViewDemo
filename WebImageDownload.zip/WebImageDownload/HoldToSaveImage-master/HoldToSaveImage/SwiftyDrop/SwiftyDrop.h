//
//  SwiftyDrop.h
//  SwiftyDrop
//
//  Created by MORITANAOKI on 2015/06/21.
//  Copyright (c) 2015年 MORITANAOKI. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for SwiftyDrop.
FOUNDATION_EXPORT double SwiftyDropVersionNumber;

//! Project version string for SwiftyDrop.
FOUNDATION_EXPORT const unsigned char SwiftyDropVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SwiftyDrop/PublicHeader.h>


